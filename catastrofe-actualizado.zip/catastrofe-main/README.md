# Catastrofe

Plugin de QGIS para consultar parcelas de la Sede Electrónica del Catastro y resaltarlas en el lienzo, sin necesidad de cargar una capa catastral.

## Búsqueda de parcelas

El panel lateral incluye tres métodos de búsqueda:

- **Por referencia catastral** (14 caracteres como mínimo).
- **Por polígono-parcela rústicos**, indicando provincia, municipio, polígono y parcela.
- **Por coordenadas UTM ETRS89 / huso 29N (EPSG:25829)**, indicando X (Este) e Y (Norte).

En cada resultado se muestran la referencia catastral y, cuando es una parcela rústica, el identificador **polígono-parcela** (por ejemplo, `1-10`). Ambos datos tienen su propio botón de copiar. También hay un botón para abrir manualmente la ficha en la Sede del Catastro.

## Modo acumulativo y limpieza

El interruptor **Modo acumulativo** permite conservar en el mapa las parcelas ya consultadas y añadir nuevas búsquedas. Las fichas anteriores permanecen disponibles junto a la última, con sus botones de copiar y abrir.

Con el modo acumulativo desactivado, cada búsqueda sustituye el resultado y el resaltado anteriores. El botón **Limpiar** elimina todas las fichas y marcas. Si el modo acumulativo estaba activado, permanece activado después de limpiar, para poder empezar una nueva serie de consultas sin volver a marcar el interruptor.

El contorno se obtiene del WFS INSPIRE de parcelas catastrales del Catastro. Si no está disponible, el plugin marca el punto central de la parcela como alternativa.

## Clic en el mapa

La herramienta de clic consulta la parcela situada bajo el cursor y muestra su referencia catastral y, si procede, el polígono-parcela. No abre el navegador automáticamente: ofrece un botón **Abrir ficha en Sede del Catastro** para hacerlo cuando se quiera. Los dos identificadores también se pueden copiar desde esa información.

## Servicios

El plugin utiliza los servicios web libres de la Sede Electrónica del Catastro:

- `Consulta_RCCOOR`: coordenadas → referencia catastral.
- `Consulta_DNPRC`: referencia → datos y URL de ficha.
- `Consulta_DNPPP`: provincia, municipio, polígono y parcela → referencias catastrales.
- WFS INSPIRE de parcelas catastrales: geometría de la parcela.

**Limitación:** el servicio del Catastro no cubre País Vasco ni Navarra, que disponen de sus propios catastros forales.

## Instalación en modo desarrollo

Copia la carpeta del plugin en el directorio `python/plugins/catastrofe` del perfil de QGIS y actívalo desde *Complementos → Administrar e instalar complementos*.

## Pruebas

Los servicios se pueden probar con Python sin iniciar QGIS:

```bash
python3 test_catastro_service.py
python3 test_hidro_service.py
python3 test_natura_service.py
```

Las pruebas que consultan servicios remotos necesitan conexión a Internet.
