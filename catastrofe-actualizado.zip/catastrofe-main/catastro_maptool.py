from qgis.core import Qgis, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject
from qgis.gui import QgsMapTool
from qgis.PyQt.QtCore import Qt, QUrl
from qgis.PyQt.QtGui import QDesktopServices
from qgis.PyQt.QtWidgets import QLabel, QPushButton, QVBoxLayout, QWidget

from .catastro_service import CatastroLookupError, datos_sedecatastro_para_punto, formato_poligono_parcela
from .portapapeles import fila_copiable

WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")


class CatastroClickTool(QgsMapTool):
    """Consulta la parcela bajo el cursor y ofrece abrir su ficha manualmente."""

    def __init__(self, canvas, iface):
        super().__init__(canvas)
        self.canvas = canvas
        self.iface = iface

    def canvasReleaseEvent(self, event):
        if event.button() != Qt.MouseButton.LeftButton:
            return
        point = self.toMapCoordinates(event.pos())
        project_crs = self.canvas.mapSettings().destinationCrs()
        transform = QgsCoordinateTransform(project_crs, WGS84, QgsProject.instance())
        try:
            point_wgs84 = transform.transform(point)
        except Exception as exc:
            self.iface.messageBar().pushWarning("Catastro", f"Coordenadas no válidas: {exc}")
            return

        self.iface.messageBar().pushMessage(
            "Catastro", "Consultando parcela…", level=Qgis.MessageLevel.Info, duration=2
        )
        try:
            datos = datos_sedecatastro_para_punto(point_wgs84.x(), point_wgs84.y())
        except CatastroLookupError as exc:
            self.iface.messageBar().pushWarning("Catastro", str(exc))
            return

        contenedor = QWidget()
        layout = QVBoxLayout(contenedor)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(fila_copiable("Referencia catastral:", datos["refcat_completa"] or datos["refcat"]))
        poligono_parcela = formato_poligono_parcela(datos["refcat"])
        if poligono_parcela:
            layout.addWidget(fila_copiable("Polígono-parcela:", poligono_parcela))
        abrir = QPushButton("Abrir ficha en Sede del Catastro")
        url = datos["url"]
        abrir.clicked.connect(lambda checked=False, destino=url: QDesktopServices.openUrl(QUrl(destino)))
        layout.addWidget(abrir)
        self.iface.messageBar().pushWidget(contenedor, level=Qgis.MessageLevel.Info)
