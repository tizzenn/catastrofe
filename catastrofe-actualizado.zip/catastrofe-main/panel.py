from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsWkbTypes,
)
from qgis.gui import QgsRubberBand
from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtGui import QColor, QDesktopServices
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QDockWidget,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .catastro_service import (
    CatastroLookupError,
    formato_poligono_parcela,
    geometria_parcela,
    naturaleza_y_referencia_completa,
    normalizar_referencia,
    punto_de_referencia,
    refcat_en_coordenadas,
    refcats_en_poligono_parcela,
    url_ficha_grafica,
)
from .portapapeles import fila_copiable
from . import settings

WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")
UTM29 = QgsCoordinateReferenceSystem("EPSG:25829")


class CatastrofePanel(QDockWidget):
    """Panel de búsqueda catastral y resaltado de parcelas en el mapa."""

    def __init__(self, iface, activar_herramienta_clic, parent=None):
        super().__init__("Buscar parcela", parent)
        self.iface = iface
        self.activar_herramienta_clic = activar_herramienta_clic
        self.rubber_bands = []
        self.resultados = []

        # Pestaña por referencia catastral.
        self.ref_edit = QLineEdit()
        self.ref_edit.setPlaceholderText("Ej. 32054A00100010")
        tab_referencia = QWidget()
        form_referencia = QFormLayout(tab_referencia)
        form_referencia.addRow("Referencia catastral:", self.ref_edit)

        # Pestaña por polígono y parcela rústicos.
        self.provincia_edit = QLineEdit()
        self.provincia_edit.setPlaceholderText("Ej. OURENSE")
        self.municipio_edit = QLineEdit()
        self.municipio_edit.setPlaceholderText("Ej. AVIÓN")
        self.poligono_edit = QLineEdit()
        self.poligono_edit.setPlaceholderText("Ej. 1")
        self.parcela_edit = QLineEdit()
        self.parcela_edit.setPlaceholderText("Ej. 10")
        tab_poligono = QWidget()
        form_poligono = QFormLayout(tab_poligono)
        form_poligono.addRow("Provincia:", self.provincia_edit)
        form_poligono.addRow("Municipio:", self.municipio_edit)
        form_poligono.addRow("Polígono:", self.poligono_edit)
        form_poligono.addRow("Parcela:", self.parcela_edit)

        # Pestaña por coordenadas UTM ETRS89 huso 29N.
        self.utm_x_edit = QLineEdit()
        self.utm_x_edit.setPlaceholderText("Ej. 580000")
        self.utm_y_edit = QLineEdit()
        self.utm_y_edit.setPlaceholderText("Ej. 4680000")
        tab_utm = QWidget()
        form_utm = QFormLayout(tab_utm)
        form_utm.addRow("X (Este):", self.utm_x_edit)
        form_utm.addRow("Y (Norte):", self.utm_y_edit)
        form_utm.addRow(QLabel("Sistema: ETRS89 / UTM huso 29N (EPSG:25829)"))

        self.tabs = QTabWidget()
        self.tabs.addTab(tab_referencia, "Por referencia")
        self.tabs.addTab(tab_poligono, "Por polígono-parcela")
        self.tabs.addTab(tab_utm, "Por coordenadas UTM")

        buscar_btn = QPushButton("Buscar")
        buscar_btn.setDefault(True)
        buscar_btn.clicked.connect(self.buscar)

        self.acumulativo_check = QCheckBox("Modo acumulativo")
        self.acumulativo_check.setToolTip(
            "Mantiene en el mapa las parcelas anteriores y añade cada nueva búsqueda."
        )
        self.limpiar_btn = QPushButton("Limpiar")
        self.limpiar_btn.clicked.connect(self.limpiar)
        controles = QHBoxLayout()
        controles.addWidget(self.acumulativo_check)
        controles.addStretch()
        controles.addWidget(self.limpiar_btn)

        self.resultados_layout = QVBoxLayout()
        self.resultados_layout.setContentsMargins(0, 6, 0, 0)
        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)

        contenido = QWidget()
        layout = QVBoxLayout(contenido)
        layout.addWidget(self.tabs)
        layout.addWidget(buscar_btn)
        layout.addLayout(controles)
        layout.addLayout(self.resultados_layout)
        layout.addWidget(self.status_label)
        layout.addStretch()
        self.setWidget(contenido)

    def buscar(self):
        self.status_label.setText("Consultando Catastro…")
        try:
            indice = self.tabs.currentIndex()
            aviso = ""
            if indice == 0:
                refcat = self._resolver_por_referencia()
            elif indice == 1:
                refcat, aviso = self._resolver_por_poligono_parcela()
            else:
                refcat = self._resolver_por_utm()
            lon, lat = punto_de_referencia(refcat)
        except (CatastroLookupError, ValueError) as exc:
            self.status_label.setText(str(exc))
            return
        except Exception as exc:
            self.status_label.setText(f"No se pudo completar la consulta: {exc}")
            return

        if not self.acumulativo_check.isChecked():
            self._vaciar_resultados_y_marcas()
        elif any(item["refcat"] == refcat for item in self.resultados):
            self.status_label.setText("Esa parcela ya está en la lista acumulada.")
            return

        try:
            datos_refcat = naturaleza_y_referencia_completa(refcat)
        except Exception:
            datos_refcat = {}
        refcat_completa = datos_refcat.get("refcat_completa") or refcat
        poligono_parcela = formato_poligono_parcela(refcat)
        try:
            url = url_ficha_grafica(refcat)
        except Exception:
            url = None

        try:
            self._marcar_en_mapa(refcat, lon, lat)
        except Exception as exc:
            self.status_label.setText(f"No se pudo marcar la parcela en el mapa: {exc}")
            return

        registro = {
            "refcat": refcat,
            "refcat_completa": refcat_completa,
            "poligono_parcela": poligono_parcela,
            "url": url,
        }
        self.resultados.append(registro)
        self._actualizar_resultados()
        self.activar_herramienta_clic()

        mensaje = "Parcela añadida al mapa." if self.acumulativo_check.isChecked() else "Parcela marcada en el mapa."
        if aviso:
            mensaje = f"{aviso} {mensaje}"
        if not url:
            mensaje += " No se pudo obtener el enlace a la ficha de Catastro."
        self.status_label.setText(mensaje)

    def _resolver_por_referencia(self):
        entrada = self.ref_edit.text().strip()
        if not entrada:
            raise CatastroLookupError("Escribe una referencia catastral.")
        return normalizar_referencia(entrada)

    def _resolver_por_poligono_parcela(self):
        provincia = self.provincia_edit.text().strip()
        municipio = self.municipio_edit.text().strip()
        poligono = self.poligono_edit.text().strip()
        parcela = self.parcela_edit.text().strip()
        if not all([provincia, municipio, poligono, parcela]):
            raise CatastroLookupError("Rellena provincia, municipio, polígono y parcela.")
        refcats = refcats_en_poligono_parcela(provincia, municipio, poligono, parcela)
        aviso = f"Hay {len(refcats)} fincas asociadas; se ha marcado la primera." if len(refcats) > 1 else ""
        return refcats[0], aviso

    def _resolver_por_utm(self):
        try:
            x = float(self.utm_x_edit.text().strip().replace(",", "."))
            y = float(self.utm_y_edit.text().strip().replace(",", "."))
        except ValueError:
            raise CatastroLookupError("Introduce coordenadas UTM X e Y válidas.")
        punto_utm = QgsPointXY(x, y)
        transform = QgsCoordinateTransform(UTM29, WGS84, QgsProject.instance())
        punto_wgs84 = transform.transform(punto_utm)
        return refcat_en_coordenadas(punto_wgs84.x(), punto_wgs84.y())

    def _crear_banda(self, geometria):
        canvas = self.iface.mapCanvas()
        banda = QgsRubberBand(canvas, geometria.type())
        color_borde = settings.color_borde()
        color_borde.setAlpha(255)
        banda.setStrokeColor(color_borde)
        banda.setWidth(settings.ancho_borde())
        if settings.relleno_activado():
            color_relleno = settings.color_relleno()
            color_relleno.setAlpha(round(settings.opacidad_relleno() * 255 / 100))
        else:
            color_relleno = QColor(0, 0, 0, 0)
        banda.setFillColor(color_relleno)
        if geometria.type() == QgsWkbTypes.PointGeometry:
            banda.setIcon(QgsRubberBand.ICON_CIRCLE)
            banda.setIconSize(14)
        banda.setToGeometry(geometria, None)
        self.rubber_bands.append(banda)

    def _marcar_en_mapa(self, refcat, lon, lat):
        canvas = self.iface.mapCanvas()
        project_crs = canvas.mapSettings().destinationCrs()
        transform = QgsCoordinateTransform(WGS84, project_crs, QgsProject.instance())
        try:
            anillo = geometria_parcela(refcat)
            puntos = [transform.transform(QgsPointXY(lon_p, lat_p)) for lon_p, lat_p in anillo]
            geometria = QgsGeometry.fromPolygonXY([puntos])
        except Exception:
            geometria = QgsGeometry.fromPointXY(transform.transform(QgsPointXY(lon, lat)))

        self._crear_banda(geometria)
        if geometria.type() == QgsWkbTypes.PolygonGeometry:
            extent = geometria.boundingBox()
            extent.scale(2.5)
            canvas.setExtent(extent)
        else:
            canvas.setCenter(transform.transform(QgsPointXY(lon, lat)))
            canvas.zoomScale(2000)
        canvas.refresh()

    def _actualizar_resultados(self):
        while self.resultados_layout.count():
            item = self.resultados_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

        if not self.resultados:
            return

        # La última parcela queda desarrollada. Las anteriores permanecen
        # compactas, pero conservan sus botones de copiar y abrir.
        for indice, registro in enumerate(self.resultados):
            ultima = indice == len(self.resultados) - 1
            tarjeta = QWidget()
            tarjeta_layout = QVBoxLayout(tarjeta)
            tarjeta_layout.setContentsMargins(0, 6, 0, 6)
            titulo = QLabel("Última parcela" if ultima else f"Parcela {indice + 1}")
            tarjeta_layout.addWidget(titulo)
            tarjeta_layout.addWidget(
                fila_copiable("Referencia catastral:", registro["refcat_completa"])
            )
            if registro["poligono_parcela"]:
                tarjeta_layout.addWidget(
                    fila_copiable("Polígono-parcela:", registro["poligono_parcela"])
                )
            if registro["url"]:
                abrir = QPushButton("Abrir ficha en Sede del Catastro")
                url = registro["url"]
                abrir.clicked.connect(lambda checked=False, destino=url: QDesktopServices.openUrl(QUrl(destino)))
                tarjeta_layout.addWidget(abrir)
            else:
                tarjeta_layout.addWidget(QLabel("Enlace a ficha no disponible"))
            self.resultados_layout.addWidget(tarjeta)

    def _vaciar_resultados_y_marcas(self):
        canvas = self.iface.mapCanvas()
        for banda in self.rubber_bands:
            try:
                canvas.scene().removeItem(banda)
                banda.deleteLater()
            except RuntimeError:
                pass
        self.rubber_bands.clear()
        self.resultados.clear()
        self._actualizar_resultados()
        canvas.refresh()

    def limpiar(self):
        """Limpia resultados y marcas sin cambiar el estado acumulativo."""
        modo_acumulativo = self.acumulativo_check.isChecked()
        self._vaciar_resultados_y_marcas()
        self.acumulativo_check.setChecked(modo_acumulativo)
        self.status_label.setText(
            "Resultados y marcas eliminados. El modo acumulativo sigue activado."
            if modo_acumulativo else "Resultados y marcas eliminados."
        )

    def limpiar_marca(self):
        """Limpieza usada al descargar el complemento."""
        self._vaciar_resultados_y_marcas()
